-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: im
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `txzh_admin`
--

DROP TABLE IF EXISTS `txzh_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '登陆名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '登陆密码',
  `sex` int(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `group_id` int(2) DEFAULT NULL COMMENT '权限角色ID',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `agent_id` int(11) DEFAULT '0' COMMENT '客户标识',
  `agent_name` varchar(255) NOT NULL DEFAULT '' COMMENT '客户(商家)名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_admin`
--

LOCK TABLES `txzh_admin` WRITE;
/*!40000 ALTER TABLE `txzh_admin` DISABLE KEYS */;
INSERT INTO `txzh_admin` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e',0,'17608035998','1975931238@qq.com',1,0,0,0,''),(8,'user','$2y$10$eA5sl1MzHc5H3aZHkEWur.DDiKDKJw6YAC/C8SyXmh4868rzZketu',0,'13800000000','792532971@qq.com',8,0,1548671342,0,''),(9,'agent','$2y$10$b5bRaCojDtS4j6moFTSUv.t/bESHmsreyK7IDEBud.q9k1XvbfMQm',0,'13800000000','792532977@qq.com',1,0,1548671411,0,'');
/*!40000 ALTER TABLE `txzh_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_auth_group`
--

DROP TABLE IF EXISTS `txzh_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '规则名称',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=开启，1=关闭',
  `rules` char(80) NOT NULL DEFAULT '' COMMENT '规则（所对应的是规则表的id）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_auth_group`
--

LOCK TABLES `txzh_auth_group` WRITE;
/*!40000 ALTER TABLE `txzh_auth_group` DISABLE KEYS */;
INSERT INTO `txzh_auth_group` VALUES (1,'asdas',0,''),(8,'asdasdas',0,'');
/*!40000 ALTER TABLE `txzh_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_auth_group_access`
--

DROP TABLE IF EXISTS `txzh_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL COMMENT '用户ID',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_auth_group_access`
--

LOCK TABLES `txzh_auth_group_access` WRITE;
/*!40000 ALTER TABLE `txzh_auth_group_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `txzh_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_auth_rule`
--

DROP TABLE IF EXISTS `txzh_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则表ID',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '路径（控制器/方法）',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则名称例如:管理员添加,修改,删除',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态：0=开启，1=关闭',
  `condition` char(100) NOT NULL DEFAULT '' COMMENT '规则表达式，为空表示存在就验证，不为空表示按照条件验证',
  `pid` int(10) unsigned DEFAULT '0',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_auth_rule`
--

LOCK TABLES `txzh_auth_rule` WRITE;
/*!40000 ALTER TABLE `txzh_auth_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `txzh_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_bsys_config`
--

DROP TABLE IF EXISTS `txzh_bsys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_bsys_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `type` varchar(256) NOT NULL DEFAULT '' COMMENT '配置类型',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置表名(不带前缀)',
  `field_key` varchar(32) NOT NULL DEFAULT '' COMMENT '配置字段名',
  `field_title` varchar(64) NOT NULL DEFAULT '' COMMENT '配置功能描述',
  `field_val` text NOT NULL COMMENT '配置字段值',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='系统公共配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_bsys_config`
--

LOCK TABLES `txzh_bsys_config` WRITE;
/*!40000 ALTER TABLE `txzh_bsys_config` DISABLE KEYS */;
INSERT INTO `txzh_bsys_config` VALUES (1,'会员','user','status','禁用会员，field_val字段中记录被禁用会员的id',',27,175,232','2019-07-02 02:08:46'),(2,'会员','user','is_servives','客服人员设置，field_val字段中记录客服人员的id',',7,27,28','2019-07-02 02:08:47');
/*!40000 ALTER TABLE `txzh_bsys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_bsys_super_log`
--

DROP TABLE IF EXISTS `txzh_bsys_super_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_bsys_super_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '超级用户操作日志表 id',
  `opt_type` int(11) NOT NULL COMMENT '操作类型',
  `content` varchar(256) NOT NULL DEFAULT '' COMMENT '组织名称',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='超级用户操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_bsys_super_log`
--

LOCK TABLES `txzh_bsys_super_log` WRITE;
/*!40000 ALTER TABLE `txzh_bsys_super_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `txzh_bsys_super_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_bsys_superuser`
--

DROP TABLE IF EXISTS `txzh_bsys_superuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_bsys_superuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `login_name` varchar(64) NOT NULL DEFAULT '' COMMENT '登录帐号',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '管理员密码',
  `user_name` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员姓名',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(64) DEFAULT NULL COMMENT '电子邮箱',
  `count` bigint(20) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `sigin_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '登录时间',
  `last_login_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最近登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='超级管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_bsys_superuser`
--

LOCK TABLES `txzh_bsys_superuser` WRITE;
/*!40000 ALTER TABLE `txzh_bsys_superuser` DISABLE KEYS */;
INSERT INTO `txzh_bsys_superuser` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e','超级管理员','13808013567','13808013567@163.com',0,'2019-07-02 02:08:46','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `txzh_bsys_superuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_capital_log`
--

DROP TABLE IF EXISTS `txzh_capital_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_capital_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `user_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '用户余额',
  `explain` varchar(255) DEFAULT NULL COMMENT '说明',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='资金明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_capital_log`
--

LOCK TABLES `txzh_capital_log` WRITE;
/*!40000 ALTER TABLE `txzh_capital_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `txzh_capital_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_login_log`
--

DROP TABLE IF EXISTS `txzh_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ip` varchar(15) DEFAULT NULL COMMENT '登陆ip',
  `details` varchar(255) DEFAULT NULL COMMENT '登陆详情',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '登陆时间',
  `agent_id` int(11) DEFAULT '0' COMMENT '客户标识',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=515 DEFAULT CHARSET=utf8 COMMENT='登陆日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_login_log`
--

LOCK TABLES `txzh_login_log` WRITE;
/*!40000 ALTER TABLE `txzh_login_log` DISABLE KEYS */;
INSERT INTO `txzh_login_log` VALUES (514,296,'--','注册登陆',1591323135,0),(513,7,'--','账号密码登陆',1591322888,0);
/*!40000 ALTER TABLE `txzh_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_system`
--

DROP TABLE IF EXISTS `txzh_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(15) NOT NULL DEFAULT '' COMMENT '设置名',
  `value` varchar(200) DEFAULT NULL COMMENT '设置的值',
  `explain` varchar(100) NOT NULL DEFAULT '' COMMENT '设置说明',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='系统设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_system`
--

LOCK TABLES `txzh_system` WRITE;
/*!40000 ALTER TABLE `txzh_system` DISABLE KEYS */;
INSERT INTO `txzh_system` VALUES (4,'JWT','{\"key\":{\"value\":\"12345678\",\"explain\":\"JWT密钥设置\"},\"time\":{\"value\":100000000,\"explain\":\"JWT有效时间设置(从用户未操作时间开始算起)\"}}','JWT设置');
/*!40000 ALTER TABLE `txzh_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `txzh_user`
--

DROP TABLE IF EXISTS `txzh_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `txzh_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `doodling` varchar(50) DEFAULT '本宝宝暂时还没有想到个性的签名' COMMENT '个性签名',
  `email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `sex` int(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `circli_img` varchar(50) DEFAULT NULL COMMENT '朋友圈背景图片',
  `is_customer_service` int(1) NOT NULL DEFAULT '0' COMMENT '1:是客服，0:不是客服',
  `agent_id` int(11) DEFAULT '0' COMMENT '客户标识',
  `custom_message` varchar(255) DEFAULT NULL COMMENT '客服消息',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=297 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txzh_user`
--

LOCK TABLES `txzh_user` WRITE;
/*!40000 ALTER TABLE `txzh_user` DISABLE KEYS */;
INSERT INTO `txzh_user` VALUES (7,'admin','管理员','我是管理员',NULL,NULL,0,'e10adc3949ba59abbe56e057f20f883e',999.00,0,1,0,1556443358,NULL,1,0,'你好，这是一个测试'),(296,'qaq123','你好呢','本宝宝暂时还没有想到个性的签名',NULL,NULL,0,'4297f44b13955235245b2497399d7a93',0.00,0,1,0,1591323135,NULL,0,0,NULL);
/*!40000 ALTER TABLE `txzh_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-05 10:14:34
